package StepDefinitions2;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class MyContactForm {
	public WebDriver driver;
	@Before
	public void setup()
	{
		String browserName = "chrome";
		switch (browserName) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;
		case "edge":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;
		default:
			System.out.println("Please provide a proper browser value.");
		}

		// Perform browser actions and configurations
		driver.manage().window().maximize();
		
	}
	@Given("I am on the application registration page")

	public void i_am_on_the_application_registration_page() {
		

		driver.get("https://www.mycontactform.com/samples/basiccontact.php");

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("I enter the following details:")
	public void i_enter_the_following_details(io.cucumber.datatable.DataTable dataTable) 
	{
		List<Map<String, String>> details = dataTable.asMaps(String.class, String.class);

		WebElement name = driver.findElement(By.name("q[1]"));
		name.sendKeys(details.get(0).get("Name"));

		WebElement emailaddress = driver.findElement(By.name("email"));
		emailaddress.sendKeys(details.get(0).get("emailaddress"));
		
		WebElement message = driver.findElement(By.name("q[2]"));
		message.sendKeys(details.get(0).get("message"));
		
		
	}

	@And("I submit the form with other details:")
	public void i_submit_the_form_with_other_details() {
	
		
		WebElement submit = driver.findElement(By.name("submit"));
		submit.click();
		
	}
	
	@Then("Registration should be successfull")
	public void registration_should_be_successfull() {
		
		WebElement mesg = driver.findElement(By.tagName("h4"));
		mesg.getText();
	}

	
	
	@After
	public void closeBrowser()
	{
		driver.quit();
	}

}

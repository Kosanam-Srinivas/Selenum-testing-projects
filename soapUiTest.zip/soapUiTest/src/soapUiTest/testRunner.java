package soapUiTest;

import java.io.IOException;
import org.apache.xmlbeans.XmlException;
import org.testng.Assert;
import org.testng.IDynamicGraph.Status;
import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.impl.wsdl.WsdlTestSuite;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
import com.eviware.soapui.model.support.PropertiesMap;
import com.eviware.soapui.model.testsuite.TestRunner;
import com.eviware.soapui.support.SoapUIException;

public class testRunner {

	public static void main(String[] args) throws XmlException, IOException, SoapUIException {

		WsdlProject project = new WsdlProject(
				"C:\\Users\\kosan\\Desktop\\Spring Boot Learn\\Web Services Or Rest APIS\\Employee.xml");

		WsdlTestSuite testSuite = project.getTestSuiteByName("Testing");

		for (int i = 0; i < testSuite.getTestCaseCount(); i++) {
			WsdlTestCase testCase = testSuite.getTestCaseAt(i);

			TestRunner runner = testCase.run(new PropertiesMap(), false);

			Assert.assertEquals(Status.FINISHED, runner.getStatus());
		}

	}

}

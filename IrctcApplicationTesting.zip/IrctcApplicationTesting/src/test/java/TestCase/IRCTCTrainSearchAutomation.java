package TestCase;
import java.util.Scanner;

import org.testng.annotations.Test;

import IRCTCautomation.miniProject.IRCTCTestAutomation;
import IRCTCautomation.miniProject.ReadExcel;

public class IRCTCTrainSearchAutomation {
	
	@Test
	public void main() throws Exception {
		
        ReadExcel re = new ReadExcel();
        IRCTCTestAutomation IRCTCTrainSearch = new IRCTCTestAutomation();

        Scanner sc = new Scanner(System.in);
        System.out.print("Choose the browser (Chrome | Edge ): ");
        String browser = sc.nextLine();

        // Initialize the WebDriver and launch the selected browser
        IRCTCTrainSearch.initializeDriver(browser);

        // Accept any alert messages if present
        IRCTCTrainSearch.acceptAlert();

        // Enter the source city based on the value read from Excel
        IRCTCTrainSearch.enterFromCity(re.readexcel(0, 0));

        // Enter the destination city based on the value read from Excel
        IRCTCTrainSearch.enterToCity(re.readexcel(1, 0));

        // Select a future date for the journey
        IRCTCTrainSearch.selectFutureDate();

        // Select the desired class from the dropdown
        IRCTCTrainSearch.selectClassDropDown();

        // Select the "Divyaang concession" checkbox if applicable
        IRCTCTrainSearch.selectDivyaangConcessionCheckbox();

        // Initiate the train search
        IRCTCTrainSearch.clickFindTrainsButton();

        // Verify the search results based on the source, destination, and date
        IRCTCTrainSearch.verifyTrainSearchResults();

        // Display the number of trains and their names
        IRCTCTrainSearch.listOfTrains();

        // Capture a screenshot of the search results
        IRCTCTrainSearch.captureScreenshot();

        // Close the browser and terminate the automation
        IRCTCTrainSearch.closeBrowser();

        sc.close();
    }

}

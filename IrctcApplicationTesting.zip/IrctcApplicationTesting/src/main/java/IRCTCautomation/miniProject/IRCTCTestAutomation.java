package IRCTCautomation.miniProject;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class IRCTCTestAutomation {
	public WebDriver driver;
	private static String baseUrl = "https://www.irctc.co.in/nget/train-search";

	// Method to initialize the WebDriver instance based on the given browser


	public void initializeDriver(String browser) throws Exception {
		if (browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			System.out.println("Chrome browser has been successfully opened.");
		} else if (browser.equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			System.out.println("Edge browser has been successfully opened.");
		} else {
			System.out.println("Invalid browser selection!");
			System.exit(0);
		}

		driver.manage().window().maximize();
		driver.get(baseUrl);
		// Verify the correct page has opened
		String expectedTitle = "IRCTC Next Generation eTicketing System";
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		//Thread.sleep(100000);
		String actualTitle = driver.getTitle();
		System.out.println("Expected Title: " + expectedTitle);
		System.out.println("Actual Title: " + actualTitle);

		if (actualTitle.equals(expectedTitle)) {
			System.out.println("Correct IRCTC website opened.");
		} else {
			System.out.println("Incorrect page opened!");
		}

		// Handle ad popup if present
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		try {
			WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='disha-banner-close']")));
			element.click();
			System.out.println("Ad Popup closed.");
		} catch (Exception e) {
			System.out.println("No Ad Popup present.");
		}
	}

	// Accept the alert messages, if no messages continue to the next step
	public void acceptAlert() {
		try {
			Alert alert = driver.switchTo().alert();
			alert.accept();
			System.out.println("Alert present. Accepted.");
		} catch (NoAlertPresentException e) {
			System.out.println("No alert present!");
		}
	}

	// Enter "Hyd" in "From city" field, in the auto search results, select the
	// "HYDERABAD DECAN - HYB" station
	public void enterFromCity(String fromCity) throws InterruptedException {
		// Locate and enter the from city
		WebElement from = driver.findElement(By.xpath("//*[@id='origin']/span/input"));
		from.sendKeys(fromCity);

		// Wait for the auto search results and select the desired station
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement fromCityOption = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']/li[2]")));
		fromCityOption.click();

		// Print the selected from city station
		System.out.println(fromCityOption.getText());
	}

	// Enter "Pune" in "To city" field, in the auto search results, select the "PUNE
	// JN - PUNE" station
	public void enterToCity(String toCity) throws InterruptedException {
		// Locate and enter the to city
		WebElement to = driver.findElement(By.xpath("//*[@id='destination']/span/input"));
		to.sendKeys(toCity);

		// Wait for the auto search results and select the desired station
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement toCityOption = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']/li")));
		toCityOption.click();

		// Print the selected to city station
		System.out.println(toCityOption.getText());
	}

	// Choose future date after 4 days from today in the journey date field
	public void selectFutureDate() throws InterruptedException {
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("d/MM/yyyy");
		WebElement calendar = driver.findElement(By.id("jDate"));
		calendar.click();

		// Check if the future date is in a different month
		if (!LocalDateTime.now().plusDays(4).getMonth().equals(LocalDateTime.now().getMonth())) {
			// Click on the next month button
			driver.findElement(By.xpath("//span[@class='ui-datepicker-next-icon pi pi-chevron-right ng-tns-c58-10']")).click();
		}

		LocalDateTime futureDateTime = LocalDateTime.now().plusDays(4);
		String futureDate = dateFormat.format(futureDateTime);
		String day = futureDate.split("/")[0];
		String month = futureDateTime.getMonth().toString();
		String year = futureDateTime.getYear() + "";

		System.out.println("Selected Date: " + day + " " + month + "/" + year);

		// Click on the specific day in the calendar
		WebElement dateElement = driver.findElement(By.linkText(day));
		dateElement.click();
	}

	// Select "Sleeper Class" from all classes Drop Down box.
	public void selectClassDropDown() throws InterruptedException {

		WebElement element = driver.findElement(By.xpath("//*[@id=\"journeyClass\"]/div/div[2]/span"));
		element.click();

		// Find the desired value and click on it
		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement element2 = wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Sleeper')]")));
		element2.click();

		System.out.println("Selected Class: " + element2.getText());
	}

	// Select the check box "Divyaang concession"
	public void selectDivyaangConcessionCheckbox() {
		WebElement divyaangCheckbox = driver.findElement(By.xpath("//label[contains(text(),'Person With Disability Concession')]"));
		if (!divyaangCheckbox.isSelected()) {
			divyaangCheckbox.click();
			System.out.println("Seleting the Person With Disability Concession....");
		}
		WebElement PopBox = driver.findElement(By.xpath("//span[contains(text(),'OK')]"));
		PopBox.click();
	}

	// Click on "Find trains" button.
	public void clickFindTrainsButton() {

		WebElement search = driver.findElement(By.xpath("//button[contains(text(),'Search')]"));
		search.submit();
		System.out.println("Click on Find trains button....");
	}

	// Verify the trains displayed are correct as per the search criteria (cities and date)
	public void verifyTrainSearchResults() {
		DateTimeFormatter Dateformat = DateTimeFormatter.ofPattern("d/MM/yyyy");
		System.out.println("!----------------Verify the trains displayed are correct as per the search criteria (cities and date)---------------------!");
		
		List<WebElement> trainListSource = driver.findElements(By.xpath("//div[@class='form-group no-pad col-xs-12 bull-back border-all']"));
		ArrayList<String> sourceLocations = new ArrayList<String>();

		// Extract source locations
		for (int i = 1; i <= trainListSource.size(); i++) {
			String from = driver.findElement(By.xpath("//app-train-list/div[4]/div/div[5]/div[" + i+ "]/div[1]/app-train-avl-enq/div[1]/div[3]/div[1]")).getText();
			sourceLocations.add(from);
		}

		List<WebElement> trainListEnding = driver.findElements(By.xpath("//div[@class='form-group no-pad col-xs-12 bull-back border-all']"));
		ArrayList<String> endingLocations = new ArrayList<String>();

		// Extract ending locations
		for (int i = 1; i <= trainListEnding.size(); i++) {
			String to = driver.findElement(By.xpath("//app-train-list/div[4]/div/div[5]/div[" + i + "]/div[1]/app-train-avl-enq/div[1]/div[3]/div[2]")).getText();
			endingLocations.add(to);
		}

		// Verify source locations and ending locations
		for (int i = 0; i < sourceLocations.size(); i++) {

			String sourceLocation = sourceLocations.get(i);
			String endingLocation = endingLocations.get(i);

			// Verify source location
			if (!sourceLocation.contains("HYDERABAD DECAN")) {
				System.out.println("The Source Location is not matched");
			} else {
				System.out.println("The Source Location is matched");
			}

			// Verify ending location
			if (!endingLocation.contains("PUNE JN")) {
				System.out.println("The Ending Location is not matched");
			} else {
				System.out.println("The Ending Location is matched");
			}
			
			// Get the element text
			String elementText = driver.findElement(By.xpath("//div[@class='col-xs-5 hidden-xs']")).getText();

			// Get the expected date and month
			String expectedDate = Dateformat.format(LocalDateTime.now().plusDays(4)).split("/")[0];

			// Check if the element text contains the expected date and month
			if (elementText.contains(expectedDate)) {
			    System.out.println("The Date is correct");
			} else {
			    System.out.println("The Date is incorrect");
			}



		}
	}

	// Display the number of trains available and their names on the console
	public void listOfTrains() {
		
		System.out.println("!----------Display the number of trains available and their names on the console---------!");
		// Find all train elements
		List<WebElement> trainList = driver.findElements(By.xpath("//div[@class='form-group no-pad col-xs-12 bull-back border-all']"));

		// Create an ArrayList to store train names
		List<String> trainNames = new ArrayList<String>();

		System.out.println("Number of trains available: " + trainList.size());

		for (int i = 1; i <= trainList.size(); i++) {
			// Find the train name element for each train
			WebElement trainNameElement = driver.findElement(By.xpath("//div[@class='ng-star-inserted']/div[" + i+ "]/div[1]/app-train-avl-enq/div[1]/div[1]/div[1]/strong"));

			// Get the train name text
			String trainName = trainNameElement.getText();

			// Add the train name to the ArrayList
			trainNames.add(trainName);
		}

		// Print the train names
		System.out.println("Train Names:");
		for (String trainName : trainNames) {
			System.out.println(trainName);
		}
	}

	int screenshotCount = 1;

	// Capture the results screenshot
	public void captureScreenshot() throws IOException, Exception {
		
		// Capture the entire page screenshot
		Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);

		// Save the screenshot to a file
		ImageIO.write(screenshot.getImage(), "PNG", new File("Screenshots//screenshot.png"));
		System.out.println("Screenshot saved successfully: ");
		
//		WebElement NodeName = driver.findElement(By.tagName("html"));
//		File screenshotFile = NodeName.getScreenshotAs(OutputType.FILE);
//		//String uniqueId = UUID.randomUUID().toString();
//
//		String screenshotFileName = "results_" + "_" + screenshotCount + ".jpg";
//
//		String userDir = System.getProperty("user.dir");
//		String screenshotFilePath = userDir + File.separator + "Screenshots" + File.separator + screenshotFileName;
//		screenshotCount++;
//
//		FileUtils.copyFile(screenshotFile, new File(screenshotFilePath));
//		System.out.println("Screenshot saved successfully: " + screenshotFileName);
	}

	// Close the application
	public void closeBrowser() {
		// Close the web browser and terminate the WebDriver instance
		driver.close();
		System.out.println("Browser closed successfully.");
	}

}
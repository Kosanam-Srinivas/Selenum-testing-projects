package policyBazaarTestScenarios;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import excelDataParser.ReadExcel;
import excelDataParser.travelInsuranceProductList;
import policyBazaarPageObjects.Smoketestingobject;
import policyBazaarPageObjects.TravelInsurancePage;
import testEnvironment.DriverSetup;

public class TravelInsuranceDetails extends DriverSetup {
	public TravelInsuranceDetails() throws Exception {
		super();
	}
	// Initialize necessary objects

	ReadExcel excel = new ReadExcel(); // Read data from excel files
	travelInsuranceProductList list = new travelInsuranceProductList();

	Smoketestingobject homepage = new Smoketestingobject();
	TravelInsurancePage travelInsurancePage = new TravelInsurancePage();

	@BeforeClass
	public void Driversetup() {
		invokeBrowser();
		System.out.println(driver.getTitle());

	}

	// Opens the travel insurance page and takes a screenshot
	@Test(priority = 1)
	public void opentravelinsurancepage() {

		extentTest = report.createTest("Policy Bazzar Travel Insurance Automation");

		try {
			homepage.travelInsurance();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Opened the travel insurance page");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Opened the travel insurance page");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	// Selects the destination country and takes a screenshot
	@Test(priority = 2)
	public void destinationCountry() throws Exception {

		try {
			travelInsurancePage.Destination(excel.readexcel(0, 1));
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected the destination country");

		} catch (Exception e) {

			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected the destination country");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	// Selects the start date for the insurance and takes a screenshot
	@Test(priority = 3)
	public void SelectStartDate() throws IOException {

		try {
			travelInsurancePage.stateDate(excel.readexcel(1, 1));
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected the start date for the insurance");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected the start date for the insurance");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	// Selects the end date for the insurance and takes a screenshot
	@Test(priority = 4)
	public void SelectEndDate() throws IOException {

		try {
			travelInsurancePage.endDate(excel.readexcel(2, 1));
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected the end date for the insurance");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected the end date for the insurance");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	// Selects the number of travelers and their ages and takes a screenshot
	@Test(priority = 5)
	public void selectNoOfTravellers() throws IOException {

		try {
			travelInsurancePage.noOfTravellers(excel.readexcel(4, 1));
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected the number of travelers");

		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected the number of travelers");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	// Indicates if there are any medical conditions and takes a screenshot
	@Test(priority = 6)
	public void medicalCondition() {

		try {
			travelInsurancePage.medical_condition();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Indicated if there are any medical conditions");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Indicated if there are any medical conditions");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	// Enters the contact details (mobile number) and takes a screenshot
	@Test(priority = 7)
	public void contactDetails() throws IOException {
		try {
			travelInsurancePage.mobileNumber(excel.readexcel(3, 1));
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Contact details");

		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Contact details");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	// Selects the student insurance plans and takes a screenshot
	@Test(priority = 8)
	public void studentPlansIcon() throws IOException {

		try {
			travelInsurancePage.studentPlans(excel.readexcel(10, 1));
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected student insurance plans");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected student insurance plans");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	// Sorts the prices of travel insurance plans and takes a screenshot
	@Test(priority = 9)
	public void SortingThePrices() {

		try {
			travelInsurancePage.sorting();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Sorted the prices of insurance plans");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Sorted the prices of insurance plans");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	// Retrieves and displays the three lowest prices of travel insurance plans and
	// takes a screenshot
	@Test(priority = 10)
	public void displayThreeLowestPrices() {

		try {
			travelInsurancePage.getTravalPlanPrices();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Retrieved and displayed the three lowest prices");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Retrieved and displayed the three lowest prices");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	// Writes the travel insurance products to a file and closes the browser
	@AfterClass
	public void driverClose() throws Exception{

		try {
			travelInsurancePage.closeBrowser();
			list.writeproducts();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Closed the browser");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Closed the browser");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}
	}

}

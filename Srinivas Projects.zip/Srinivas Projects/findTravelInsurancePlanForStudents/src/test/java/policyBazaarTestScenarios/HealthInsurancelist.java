package policyBazaarTestScenarios;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import captureThePage.captureScreenshot;
import excelDataParser.healthMenulist;
import policyBazaarPageObjects.HealthInsurance;
import testEnvironment.DriverSetup;

public class HealthInsurancelist extends DriverSetup {

	public HealthInsurancelist() throws Exception {
		super();
	}

	// Instance of healthMenulist class for parsing health insurance data.
	healthMenulist list = new healthMenulist();
	// Instance of captureScreenshot class for taking screenshots.
	captureScreenshot screenshot = new captureScreenshot();
	// Instance of HealthInsurance class for health insurance-related operations.
	HealthInsurance HInsurance = new HealthInsurance();

	@BeforeClass
	public void Driversetup() throws Exception {
		// Invoke the browser setup method from the parent class.
		invokeBrowser();
		WebElement homepageCaptutre = driver.findElement(By.cssSelector("html.webp"));
		screenshot.takescreenshot(homepageCaptutre,"HomePageHealthInsurance");
		System.out.println(driver.getTitle());

	}

	@Test(priority = 1)
	public void getHealthMenu() throws IOException, InterruptedException {

		// Get the health insurance products from the menu.
		extentTest = report.createTest("PolicyBazaar Health Insurance Automation");
		try {
			HInsurance.gethealthinsuranceproducts();
			WebElement healthMenu = driver.findElement(By.cssSelector("div.ruby-grid"));
			screenshot.takescreenshot(healthMenu,"HealthMenuList");
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Getting HealthInsurance Menu List");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Getting HealthInsurance Menu List");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;

		}

	}

	@AfterClass
	public void closeDriver() throws Exception { 
		// Parse the health insurance list.

		try {
			list.healthlist();
			HInsurance.CloseBrowser();// Close the browser.
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Close The Browser");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Close The Browser");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}
}

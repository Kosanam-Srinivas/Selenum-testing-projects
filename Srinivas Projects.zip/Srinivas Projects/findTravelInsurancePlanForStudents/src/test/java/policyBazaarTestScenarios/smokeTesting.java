package policyBazaarTestScenarios;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import policyBazaarPageObjects.Smoketestingobject;
import testEnvironment.DriverSetup;

public class smokeTesting extends DriverSetup {

	public smokeTesting() throws Exception {
		super();
	}

	Smoketestingobject smokeTesting = new Smoketestingobject();

	@BeforeClass
	public void setUpEnvironment() {
		extentTest = report.createTest("Smoke Testing");

		try {
			smokeTesting.driverSetupAndHomepage();
			extentTest.pass("driverSetup And Homepage passed");
			extentTest.log(Status.INFO, "Homepage opend");
		} catch (Exception e) {
			extentTest.fail("driverSetup And Homepage failed");
			extentTest.log(Status.INFO, "Homepage opend");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			e.printStackTrace();
		}

	}

	@Test(priority = 1)
	public void smokeTestOfTravelInsurance() {

		try {
			smokeTesting.travelInsurance();
			extentTest.pass("SmokeTest Of TravelInsurance passed");
			extentTest.log(Status.INFO, "smokeTest Of TravelInsurance");
		} catch (Exception e) {
			extentTest.fail("SmokeTest Of TravelInsurance failed");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 2)
	public void smokeTestOfHealthInsurance() {

		try {
			smokeTesting.healthInsurance();
			extentTest.pass("smokeTest Of HealthInsurance passed");
			extentTest.log(Status.INFO, "smokeTest Of HealthInsurance");
		} catch (Exception e) {
			extentTest.fail("smokeTest Of HealthInsurance failed");
			extentTest.log(Status.INFO, "smokeTest Of HealthInsurance");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}
	}

	@Test(priority = 3)
	public void smokeTestOfCarInsurance() {
		try {
			smokeTesting.carInsurance();
			extentTest.pass("smokeTest Of CarInsurance passed");
			extentTest.log(Status.INFO, "smokeTest Of CarInsurance");
		} catch (Exception e) {
			extentTest.fail("smokeTest Of CarInsurance failed");
			extentTest.log(Status.INFO, "smokeTest Of CarInsurance");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@AfterClass
	public void driverClose() throws Exception{

		try {
			smokeTesting.closeBrowser();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Closed the browser");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Closed the browser");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}
	}

}

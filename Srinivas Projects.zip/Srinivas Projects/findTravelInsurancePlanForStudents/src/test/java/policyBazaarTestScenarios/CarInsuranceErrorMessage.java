package policyBazaarTestScenarios;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import captureThePage.captureScreenshot;
import excelDataParser.ReadExcel;
import policyBazaarPageObjects.CarInsurancePage;
import testEnvironment.DriverSetup;

public class CarInsuranceErrorMessage extends DriverSetup {

	public CarInsuranceErrorMessage() throws Exception {
		super();
	}

	ReadExcel excel = new ReadExcel(); // Read data from excel files

	CarInsurancePage carInsurance = new CarInsurancePage();
	captureScreenshot screenshot = new captureScreenshot();

	@BeforeClass
	public void Driversetup() throws Exception {
		// Setting up the driver and opening the browser
		invokeBrowser();
		System.out.println(driver.getTitle());

	}

	@Test(priority = 1)
	public void clickInsuranceProductbutton() throws IOException {
		extentTest = report.createTest("PolicyBazaar carInsurance Insurance Automation");

		try {
			carInsurance.InsuranceProductsbutton();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Clicked Insurance Products button");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Clicked Insurance Products button");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 2)
	public void carInsuranceInsurance() throws IOException {
		// Clicking the carInsurance Insurance button
		try {
			carInsurance.CarInsurancebutton();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Clicked carInsurance Insurance button");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Clicked carInsurance Insurance button");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 3)
	public void WithOutcarInsuranceNumber() throws IOException {
		// Proceeding without entering a carInsurance number
		try {
			carInsurance.ProceedWithoutCarNumber();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Proceeded without entering carInsurance Number");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Proceeded without entering carInsurance Number");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 4)
	public void ChooseCity() throws IOException {
		// Selecting a city
		try {
			carInsurance.selectCity();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected a City");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected a City");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 5)
	public void carInsuranceBrand() throws IOException {
		// Selecting a carInsurance brand
		try {
			carInsurance.selectcarbrand();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected a carInsurance Brand");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected a carInsurance Brand");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 6)
	public void carInsuranceModel() throws IOException {
		// Selecting a carInsurance model
		try {
			carInsurance.SelectCarModel(excel.readexcel(11, 1));
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected a carInsurance Model");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected a carInsurance Model");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 7)
	public void carInsuranceFuelType() throws IOException {
		// Selecting a carInsurance fuel type
		try {
			carInsurance.SelectFuelType();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected a carInsurance Fuel Type");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected a carInsurance Fuel Type");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 8)
	public void carInsurancevariant() throws IOException {
		// Selecting a carInsurance variant
		try {
			carInsurance.SelectCarvariant();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected a carInsurance Variant");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected a carInsurance Variant");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 9)
	public void carInsuranceRegistrationYear() throws IOException {
		// Selecting a carInsurance registration year
		try {
			carInsurance.SelectCarRegistrationYear();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Selected a carInsurance Registration Year And Month");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Selected a carInsurance Registration Year And Month");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 10)
	public void fullName() throws IOException {
		// Filling the full name
		try {
			carInsurance.FillFullName(excel.readexcel(7, 1));
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Filled the Full Name");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Filled the Full Name");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 11)
	public void email() throws IOException {
		// Filling the email
		try {
			carInsurance.FillEmail(excel.readexcel(8, 1));
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Filled the Email");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Filled the Email");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 12)
	public void mobileNumber() throws IOException {
		// Filling the mobile number
		try {
			carInsurance.FillMobileNumber(excel.readexcel(9, 1));
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Filled the Mobile Number");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Filled the Mobile Number");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@Test(priority = 13)
	public void displayErrorMessage() throws Exception {
		// Displaying the error message
		try {
			carInsurance.ErrorMessage();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Displayed Error Message");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Displayed Error Message");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}

	}

	@AfterClass
	public void driverClose() throws Exception {
		// Closing the browser
		try {
			carInsurance.closeBrowser();
			extentTest.log(Status.PASS, "TestCase Passed");
			extentTest.log(Status.INFO, "Browser Closed");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "TestCase Failed");
			extentTest.log(Status.INFO, "Browser Closed");
			extentTest.log(Status.ERROR, "Reason for the failure: " + e.getMessage());
			throw e;
		}
	}

}
package excelDataParser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import policyBazaarPageObjects.HealthInsurance;

public class healthMenulist extends HealthInsurance {

    public healthMenulist() throws Exception {
        super(); // Call the constructor of the superclass HealthInsurance
    }

    public void healthlist() throws IOException, Exception {
        // Get the current working directory
        String userDir = System.getProperty("user.dir");
        
        // Define the file path for the Excel file
        String filePath = userDir + "\\src\\test\\java\\excelDataFiles\\HealthInsuranceMenuList.xlsx";
        
        // Create a File object with the specified file path
        File src = new File(filePath);
        
        // Create a FileInputStream to read from the Excel file
        FileInputStream fis = new FileInputStream(src);
        
        // Create a new XSSFWorkbook object to represent the Excel workbook
        XSSFWorkbook workbook = new XSSFWorkbook();
        
        // Create a new XSSFSheet object with the name "travelinsuranceprice"
        XSSFSheet sheet = workbook.createSheet("travelinsuranceprice");
        
        // Get the size of the healthlist
        int size = healthlist.size();

        // Initialize the row number for creating rows in the sheet
        int rows = 0;

        // Iterate over the healthlist and populate the Excel sheet
		for (int i = 0; i < size; i++) {
			// Create a new row in the sheet
			Row row = sheet.createRow(rows++);

			row.createCell(0).setCellValue(healthlist.get(i)); // Set the cell value in column 0 with the value from the
																// healthlist
		}
        
        FileOutputStream out = new FileOutputStream(src);  // Create a FileOutputStream to write the workbook data to the Excel file
        
        // Write the workbook data to the output stream
        workbook.write(out);
        workbook.close();
    }
}

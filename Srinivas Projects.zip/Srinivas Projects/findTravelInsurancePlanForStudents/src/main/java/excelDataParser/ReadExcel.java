package excelDataParser;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
    public String readexcel(int row, int cell) throws IOException {
        // Get the current working directory
        String userDir = System.getProperty("user.dir");
        
        // Define the file path for the Excel file
        String filePath = userDir + "\\src\\test\\java\\excelDataFiles\\PolicyBazaarTestData.xlsx";
        
        // Create a File object with the specified file path
        File file = new File(filePath);
        
        // Create a FileInputStream to read from the Excel file
        FileInputStream fis = new FileInputStream(file);
        
        // Create a new XSSFWorkbook object to represent the Excel workbook
        XSSFWorkbook wb = new XSSFWorkbook(fis);
        
        // Get the first sheet of the workbook
        XSSFSheet sheet = wb.getSheetAt(0);
        
        // Read the value from the specified row and cell in the sheet
        return String.valueOf(sheet.getRow(row).getCell(cell));
    }
}

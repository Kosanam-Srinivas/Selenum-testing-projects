package excelDataParser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import policyBazaarPageObjects.TravelInsurancePage;

public class travelInsuranceProductList extends TravelInsurancePage {

	public travelInsuranceProductList() throws Exception {
		super(); // Call the constructor of the superclass TravelInsurancePage
	}

	String userDir = System.getProperty("user.dir");
	String filePath = userDir + "\\src\\test\\java\\excelDataFiles\\TravelInsuranceProductsandPrices.xlsx";

	public void writeproducts() throws IOException {
		// Create a File object with the specified file path
		File src = new File(filePath);

		// Create a FileInputStream to read from the Excel file
		
		FileInputStream fis = new FileInputStream(src);

		// Create a new XSSFWorkbook object to represent the Excel workbook

		XSSFWorkbook workBook = new XSSFWorkbook();

		// Create a new XSSFSheet object with the name "travelinsurance"
		XSSFSheet sheet = workBook.createSheet("travelinsurance");

		// Create the first row in the sheet
		Row row1 = sheet.createRow(0);

		// Create the second row in the sheet
		Row row2 = sheet.createRow(1);

		// Get the size of the travelInsuranceProviderNames list
		int size = travelInsuranceProviderNames.size();

		// Get the size of the travelInsurancePrice list
		int len = travelInsurancePrice.size();

		int colnum1 = 0; // Initialize the column number for creating cells in row1

		// Iterate over the travelInsuranceProviderNames list and populate row1
		for (int i = 0; i < size; i++) {
			row1.createCell(colnum1++).setCellValue(travelInsuranceProviderNames.get(i));
		}

		int colnum2 = 0; // Initialize the column number for creating cells in row2

		// Iterate over the travelInsurancePrice list and populate row2
		for (int j = 0; j < len; j++) {
			row2.createCell(colnum2++).setCellValue(travelInsurancePrice.get(j));
		}

		// Create a FileOutputStream to write the workbook data to the Excel file
		FileOutputStream out = new FileOutputStream(src);

		// Write the workbook data to the output stream
		workBook.write(out);
		workBook.close();

	}
}

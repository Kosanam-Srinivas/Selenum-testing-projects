package excelDataParser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;

public class ExtentReportManager {

	public static ExtentReports report; // The ExtentReports object to manage the report
	private static Properties properties; // Properties object to store configuration properties

	public static ExtentReports getReportInstance() throws IOException {

		try {
			String userDir = System.getProperty("user.dir");
			properties = new Properties();
			FileInputStream inputStream = new FileInputStream(userDir + "\\src\\main\\java\\configurationproperties\\configuration.properties");

			// Loading properties file
			properties.load(inputStream);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 

		if (report == null) { // Check if the report object is null to create a new report

			Date date = new Date();     // Generate a unique report name based on the current date and time
			
			String reportName = date.toString().replace(":", "_").replace(" ", "_") + ".html";

			ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "\\ExtentReports\\" + "ExtentReport"+reportName);
			// Create a new ExtentHtmlReporter with the report file path

			report = new ExtentReports(); // Instantiate a new ExtentReports object
			report.attachReporter(htmlReporter); // Attach the ExtentHtmlReporter to the ExtentReports object

			// Set system information for the report
			report.setSystemInfo("OS", "Windows 11");
			report.setSystemInfo("Environment", "UAT");
			report.setSystemInfo("Build Number", "10.8.1");
			report.setSystemInfo("Browser", properties.getProperty("browser"));
			report.setSystemInfo("URL", properties.getProperty("url"));

			// Configure the ExtentHtmlReporter
			htmlReporter.config().setDocumentTitle("PolicyBazzar Test Results");
			htmlReporter.config().setReportName("policyBazzar Automation Testing");
			htmlReporter.config().setTestViewChartLocation(ChartLocation.BOTTOM);
			htmlReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");
		}

		return report; // Return the ExtentReports object
	}
}

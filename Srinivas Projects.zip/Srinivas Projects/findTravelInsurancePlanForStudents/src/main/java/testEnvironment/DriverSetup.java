package testEnvironment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Duration;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import excelDataParser.ExtentReportManager;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverSetup {

	// Properties object to store configuration properties
	protected static Properties properties;

	// WebDriver instance to interact with the browser
	protected static WebDriver driver;

	// Logger for logging messages	
	protected static final Logger logger = LogManager.getLogger(testEnvironment.DriverSetup.class);

	// ExtentReports object for generating test reports
	protected ExtentReports report = ExtentReportManager.getReportInstance();

	// ExtentTest object for logging test steps
	protected ExtentTest extentTest;

	// Constructor to initialize configuration properties
	public DriverSetup() throws Exception {
		try {
			String userDir = System.getProperty("user.dir");
			properties = new Properties();
			FileInputStream inputStream = new FileInputStream(userDir + "\\src\\main\\java\\configurationproperties\\configuration.properties");

			// Loading properties file
			properties.load(inputStream);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	// Method to invoke the browser based on configuration
	public static void invokeBrowser() {

		String browserName = properties.getProperty("browser");

		switch (browserName.toLowerCase()) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;
		case "edge":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;
		default:
			System.out.println("Please provide a proper browser value.");
		}

		// Perform browser actions and configurations
		driver.manage().window().maximize();

		driver.get(properties.getProperty("url"));

		driver.manage().deleteAllCookies();

		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	// Method to flush the test reports
	@AfterMethod
	public void flushReports() throws Exception {
		report.flush();
	}
}

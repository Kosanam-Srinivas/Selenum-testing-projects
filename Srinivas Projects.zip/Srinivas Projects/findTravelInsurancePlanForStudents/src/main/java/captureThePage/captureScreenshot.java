package captureThePage;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;

public class captureScreenshot {

	public String takescreenshot(WebElement NodeName, String screenshotName) {
		// Take a screenshot

		File screenshotFile = NodeName.getScreenshotAs(OutputType.FILE);
		String fileName = screenshotName + ".png";

		// Save the screenshot file with the generated filename
		try {
			String userDir = System.getProperty("user.dir");
			FileUtils.copyFile(screenshotFile, new File(userDir + "\\Screenshot\\" + fileName));
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;

	}

}

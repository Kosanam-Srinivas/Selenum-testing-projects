package policyBazaarPageObjects;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import captureThePage.captureScreenshot;
import testEnvironment.DriverSetup;

public class TravelInsurancePage extends DriverSetup {

	captureScreenshot capture = new captureScreenshot();

	public TravelInsurancePage() throws Exception {
		super();// Call the constructor of the superclass DriverSetup
	}

	 //Enters the destination country in the input box and moves to the next page.
	
	By DestinationInputBox = By.xpath("//input[@id='country']");
	By MovetoNextpage = By.xpath("//button[@class='travel_main_cta']");
	public void Destination(String country) {

		WebElement destinationInput = driver.findElement(DestinationInputBox);
		destinationInput.click();
		destinationInput.sendKeys(country);

		// Select the destination country from the search list
		// Wait for the search list to be visible and select the destination country
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        String countryXpath = "//ul[@class='search-list']/li[contains(text(),'" + country + "')]";
        WebElement destinationCountryOption = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(countryXpath)));
        destinationCountryOption.click();
		
		WebElement drstinationCaptutre = driver.findElement(By.cssSelector("body.preQuote-body"));
		capture.takescreenshot(drstinationCaptutre,"drstinationCaptutre");
		
		// Move to the next page
		driver.findElement(MovetoNextpage).click();
		System.out.println(country);

	}

	/**
	 * Selects the start date for the travel insurance and moves to the next page.	 * 
	 * @param startDate The start date to select in the format "dd/MM/yyyy".
	 */
	By StartDateField = By.xpath("//div[2]/div/div[1]/div/div[1]/div/div/input");
	public void stateDate(String startDate)  {
		// Select the start date
		driver.findElement(StartDateField).click();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		
		// Parse the start date from the input string
		SimpleDateFormat inputformat = new SimpleDateFormat("dd/MM/yyyy");

		SimpleDateFormat outputformat = new SimpleDateFormat("MMM d, yyyy");

		String output = null;

		try {

			Date date = inputformat.parse(startDate);

			output = outputformat.format(date);

			System.out.println("Start Date: " + output);

		} catch (Exception e) {

			System.out.println("Invalid date format");

		}

		String sdate = "//button[@aria-label='"+output+"']";			

		WebElement selectStartDate =driver.findElement(By.xpath(sdate));

		selectStartDate.click();		

	}

	/**
	 * Selects the end date for the travel insurance and moves to the next page.
	 */
	By endDateField = By.xpath("//div[2]/div/div[1]/div/div[2]/div/div/input");
	public void endDate(String endDate)  {
		// Parse the end date from the input string
		//driver.findElement(endDateField).click();

		SimpleDateFormat inputformat = new SimpleDateFormat("dd/MM/yyyy");

		SimpleDateFormat outputformat = new SimpleDateFormat("MMM d, yyyy");

		String output = null;

		try {

			Date date = inputformat.parse(endDate);

			output = outputformat.format(date);

			System.out.println("End Date: " + output);

		} catch (Exception e) {

			System.out.println("Invalid date format");

		}

		String edate = "//button[@aria-label='"+output+"']";
		
		

		WebElement selectEndDate = driver.findElement(By.xpath(edate));

		selectEndDate.click();
		
		WebElement datesPageCaptutre = driver.findElement(By.cssSelector("body.preQuote-body"));
		capture.takescreenshot(datesPageCaptutre,"datesPageCaptutre");
		

		// Move to the next page
		driver.findElement(MovetoNextpage).click();

	}

	/**
	 * Selects the number of students and their ages and moves to the next page.
	 */
	// Locators
	By SelectAgeOne = By.xpath("//label[text()='22 years']");
	By SelectAgoTwo = By.xpath("//label[text()='21 years']");
	By StudentOneDropdown = By.xpath("//div[text()='Select age of traveller 1']");
	By StudentTwoDropdown = By.xpath("//div[text()='Select age of traveller 2']");

	public void noOfTravellers(String NoOfStudents)  {
		WebElement NoofStudents = driver.findElement(By.xpath("//label[text()=" + NoOfStudents + "]"));
		NoofStudents.click();
		driver.findElement(StudentOneDropdown).click();
		driver.findElement(SelectAgeOne).click();
		driver.findElement(StudentTwoDropdown).click();
		driver.findElement(SelectAgoTwo).click();
		
		WebElement noOfStudentsCaptutre = driver.findElement(By.cssSelector("body.preQuote-body"));
		capture.takescreenshot(noOfStudentsCaptutre,"noOfStudentsCaptutre");
		

		driver.findElement(MovetoNextpage).click();

	}

	/**
	 * Selects "No" for the medical condition and moves to the next page.
	 */
	By No = By.xpath("//label[text()='No']");

	public void medical_condition() {

		driver.findElement(No).click();

		WebElement medicalConditionPageCaptutre = driver.findElement(By.cssSelector("body.preQuote-body"));
		capture.takescreenshot(medicalConditionPageCaptutre, "medicalConditionPageCaptutre");
		try {
			WebElement moveToNextPageElement = driver.findElement(MovetoNextpage);

			moveToNextPageElement.click();

		} catch (Exception e) {
			System.out.println("Error: The 'MovetoNextpage' element is not clickable within the timeout.");
		}

	}

	/**
	 * Enters the mobile number and moves to the next page.	 * 
	 * @param PNumber The mobile number to enter.
	 */
	// Locators
	By numberField = By.xpath("//input[@id='mobileNumber']");
	//By slideOff = By.className("slider round");
	public void mobileNumber(String PNumber) {
		WebElement textField = driver.findElement(numberField);
		textField.click();
		textField.sendKeys(PNumber);
		//driver.findElement(slideOff).click();
		
		WebElement mobileNumberPageCaptutre = driver.findElement(By.cssSelector("body.preQuote-body"));
		capture.takescreenshot(mobileNumberPageCaptutre,"mobileNumberPageCaptutre");
		driver.findElement(MovetoNextpage).click();

	}

	/**
	 * Selects student plans and their durations and clicks Apply.	 */
	// Locators
	By identify = By.xpath("//button[@class='travel_main_cta']");
	By StudentPlans = By.xpath("//label[@for='student-trip-desktop']");
	By student1CheckBox = By.xpath("//label[@for='Traveller_1']");
	By student2CheckBox = By.xpath("//label[@for='Traveller_2']");
	By ApplyBtn = By.xpath("//button[contains(text(), 'Apply')]");
	public void studentPlans(String noOfDays) {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(identify));
	
		driver.findElement(StudentPlans).click();
		driver.findElement(student1CheckBox).click();
		driver.findElement(student2CheckBox).click();
	
		Select plansOfStudent = new Select(driver.findElement(By.xpath("//select[@id='feet']")));
		plansOfStudent.selectByVisibleText(noOfDays);
		
		WebElement StudentsPlansPageCaptutre = driver.findElement(By.cssSelector("body.quotes-body"));
		capture.takescreenshot(StudentsPlansPageCaptutre,"StudentsPlansPageCaptutre");

		driver.findElement(ApplyBtn).click();
	}

	/**
	 * Selects the sorting option for travel insurance quotes and clicks Apply.
	 */

	// Locators
	By SortingDropdown = By.xpath("//div[contains(@class,'quotesFilters row_wrap')]/ul/li[2]");
	By selectOption = By.xpath("//label[contains(text(), 'Premium low to high')]");
	By ApplyButton = By.xpath("//button[contains(text(), 'Apply')]");
	public void sorting(){

		driver.findElement(SortingDropdown).click();
		driver.findElement(selectOption).click();
		WebElement sortingSectionCaptutre = driver.findElement(By.cssSelector("div.quotesFilters__window"));
		capture.takescreenshot(sortingSectionCaptutre,"sortingSectionCaptutre");
		driver.findElement(ApplyButton).click();

	}

	/**
	 * Retrieves travel insurance plan names and prices and stores them in
	 * ArrayLists.
	 */

	// Locators
	By providerCompany = By.xpath("//p[@class='quotesCard--insurerName']");
	By insurancePrice = By.xpath("//span[@class='premiumPlanPrice']");
	protected static ArrayList<String> travelInsuranceProviderNames = new ArrayList<String>();
	protected static ArrayList<String> travelInsurancePrice = new ArrayList<String>();
	public void getTravalPlanPrices() {		

		List<WebElement> insuranceProviderList = driver.findElements(providerCompany).subList(0, 3);
		List<WebElement> productPriceList = driver.findElements(insurancePrice).subList(0, 3);
		for (WebElement travelinsuranceProviderName : insuranceProviderList) {

			// Retrieved from class attribute value By replacing Logo String and added to ArrayList
			travelInsuranceProviderNames.add(travelinsuranceProviderName.getAttribute("innerText"));

		}
		for (WebElement price : productPriceList) {
			// Price is retrieved and added to ArrayList
			travelInsurancePrice.add(price.getText().substring(1));

		}
		System.out.println("InsuranceCompanyProviderNames: " + travelInsuranceProviderNames);
		System.out.println("InsurancePrice: " + travelInsurancePrice);
		
		
	}

	// Closes the browser.
	public void closeBrowser() {
		WebElement TravalPlanPricesCaptutre = driver.findElement(By.cssSelector("body.quotes-body"));
		capture.takescreenshot(TravalPlanPricesCaptutre,"TravalPlanPricesCaptutre");
		driver.quit();
	}

}

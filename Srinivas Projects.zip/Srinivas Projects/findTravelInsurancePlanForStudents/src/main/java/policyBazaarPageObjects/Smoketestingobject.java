package policyBazaarPageObjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import testEnvironment.DriverSetup;

public class Smoketestingobject extends DriverSetup {

	public Smoketestingobject() throws Exception {
		super();
	}

	By travelInsurance = By.xpath("//i[contains(@class,'icon-bg-new ti')]");
	By insuranceProducts = By.xpath("//a[contains(text(),'Insurance Products')]");
	By healthInsurance = By.xpath("//div[@class='ruby-col-3 hidden-md'][2]/h3");
	By carInsurance = By.xpath("//div[@class='ruby-col-3 hidden-md'][3]/h3/a");

	public void driverSetupAndHomepage() {

		invokeBrowser();

		String applicationTitle = driver.getTitle();

		assert applicationTitle.equals("Insurance - Compare & Buy Insurance Plans – Health, Term, Life, Car"): "Application is not correctly opend.";
		
		System.out.println("Application should be correctly displayed");

	}

	public void travelInsurance() {

		WebElement travelInsuranceElement = driver.findElement(travelInsurance);

		// Verify if the element is clickable
		if (travelInsuranceElement.isEnabled()) {
			travelInsuranceElement.click();
			System.out.println("Clicked on Travel Insurance");
			
		} else {
			System.out.println("Travel Insurance element is not clickable");
		}

	}

	public void healthInsurance() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.navigate().to(properties.getProperty("url"));
		
		WebElement InsuranceProducts = driver.findElement(insuranceProducts);
	
		InsuranceProducts.click();
		WebElement healthInsuranceElement = driver.findElement(healthInsurance);
		// Verify if the element is displayed
		if (healthInsuranceElement.isDisplayed()) {
			System.out.println("Health Insurance is displayed");
			String healthInsuranceText = healthInsuranceElement.getText();
			System.out.println("Health Insurance Text: " + healthInsuranceText);
		} else {
			System.out.println("Health Insurance is not displayed");
		}

	}

	public void carInsurance() {
		WebElement carInsuranceElement = driver.findElement(carInsurance);

		// Verify if the element is clickable
		if (carInsuranceElement.isEnabled()) {
			carInsuranceElement.click();
			System.out.println("Clicked on Car Insurance");
		} else {
			System.out.println("Car Insurance element is not clickable");
		}
	}
	
	public void closeBrowser() {
		driver.quit();
	}

}

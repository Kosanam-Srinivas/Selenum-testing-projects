package policyBazaarPageObjects;

import java.io.IOException;
import java.time.Duration;

import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import captureThePage.captureScreenshot;
import testEnvironment.DriverSetup;

public class CarInsurancePage extends DriverSetup {
	captureScreenshot capture = new captureScreenshot();
	public CarInsurancePage() throws Exception {
		super();
	}
	
	By InsuranceProductsDropdown = By.xpath("//a[text()='Insurance Products ']");
	public void InsuranceProductsbutton() {
		
		// Clicking the Insurance Products button
    	driver.findElement(InsuranceProductsDropdown).click();
    }
	
	By CarInsurance = By.xpath("//a[@class='headlink' and contains(text(), 'Car Insurance')]");
	public void CarInsurancebutton() {
		// Clicking the Car Insurance button
		WebElement CarInsurancebutton = driver.findElement(By.cssSelector("div.ruby-grid"));
		capture.takescreenshot(CarInsurancebutton,"CarInsurancebutton");
    	driver.findElement(CarInsurance).click();
    	
    }
	
	By CarQuote = By.xpath("//*[@id='step-one-pq']/div/div/div[1]");
	By AdPopup = By.xpath("//div[@class='exit-intent-popup-close']");
	By WithOutCarNo = By.xpath("//div/button[contains(text(), 'Proceed without car number')]");
	public void ProceedWithoutCarNumber() {	
		// Proceeding without entering a car number
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));		    
	    try {	  
	    	WebElement element1 = wait.until(ExpectedConditions.visibilityOfElementLocated(CarQuote));
	    	String CarQuoteText = element1.getText();
	    	System.out.println(CarQuoteText);
	    	extentTest = report.createTest("Test Error Messages and CarQuoteText");
	    	extentTest.log(Status.PASS, "CarQuoteText Messages");
			extentTest.log(Status.INFO, CarQuoteText);
	    		
			WebElement element = wait.until(ExpectedConditions.elementToBeClickable(AdPopup));
			element.click();
            System.out.println("Ad Popup closed.");
           
        }
	    catch (Exception e) {
            System.out.println("No Ad PopUp present!!!!");
        }  
	    WebElement ProceedWithoutCarNumber = driver.findElement(By.cssSelector("html#navigatorType"));
		capture.takescreenshot(ProceedWithoutCarNumber,"ProceedWithoutCarNumber");
	    driver.findElement(WithOutCarNo).click();
		
	}
	
	By Place = By.xpath("//div[@data-step='2']//div[contains(text(), 'Delhi')]");
	By RTO = By.xpath("//div[@data-step='2']//span[contains(text(), 'DL5')]");
	public void selectCity() {
		// Selecting a city
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));		    
	    try {	
	    	WebElement selectCity = driver.findElement(By.cssSelector("body.stopscroll"));
			capture.takescreenshot(selectCity,"selectCity");
	    	
			WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(Place));
			element1.click();
			WebElement element2 = wait.until(ExpectedConditions.elementToBeClickable(RTO));
			element2.click();
          
        }
	    catch (Exception e) {
	    	e.printStackTrace();
        }  

    }
	
	By carName = By.xpath("//img[@alt='Kia']");
	public void selectcarbrand(){
		WebElement selectcarbrand = driver.findElement(By.cssSelector("body.stopscroll"));
		capture.takescreenshot(selectcarbrand,"selectcarbrand");
		// Selecting a car brand
    	driver.findElement(carName).click();
    }
	
	By searchBox = By.xpath("//input[@placeholder='Search model']");
	By CarModel = By.xpath("//li[@class = 'ui-menu-item']/div[text()='SELTOS']");
	public void SelectCarModel(String carModel) {
		WebElement carModelSearchBox = driver.findElement(searchBox);
		carModelSearchBox.click();
		carModelSearchBox.sendKeys(carModel);
		
		WebElement SelectCarModelCapture = driver.findElement(By.cssSelector("body.stopscroll"));
		capture.takescreenshot(SelectCarModelCapture,"SelectCarModel");
		// Selecting a car model
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		WebElement SelectCarModel = wait.until(ExpectedConditions.visibilityOfElementLocated(CarModel));
		SelectCarModel.click();
		
	}
	
	By fuelType = By.xpath("//span[text()='Petrol']");
	public void SelectFuelType() {
		WebElement SelectFuelType = driver.findElement(By.cssSelector("body.stopscroll"));
		capture.takescreenshot(SelectFuelType,"SelectFuelType");
		// Selecting a car fuel type
		driver.findElement(fuelType).click();
	}
	
	By carVariant = By.xpath("//span[text()='HTX IVT']");
	//span[text()='HTX IVT']
	public void SelectCarvariant() {
		WebElement SelectCarvariant = driver.findElement(By.cssSelector("body.stopscroll"));
		capture.takescreenshot(SelectCarvariant,"SelectCarvariant");
		// Selecting a car variant
		driver.findElement(carVariant).click();
	}
	
	By RegistrationYear = By.xpath("//span[text()=2022]");
	By RegistrationMonth = By.xpath("//span[text()='Jan']");
	public void SelectCarRegistrationYear() {
		// Selecting a car registration year and month
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));		    
	    try {	    	
			WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(RegistrationYear));
			element1.click();
			WebElement SelectCarRegistrationYear = driver.findElement(By.cssSelector("body.stopscroll"));
			capture.takescreenshot(SelectCarRegistrationYear,"SelectCarRegistrationYear");
//			WebElement element2 = wait.until(ExpectedConditions.visibilityOfElementLocated(RegistrationMonth));
//			element2.click();
          
        }
	    catch (Exception e) {
	    	e.printStackTrace();
        }
	}
	
	By fullName = By.xpath("//input[@id='txtName']");
	public void FillFullName(String fullname) {
		// Filling the full name
		driver.findElement(fullName).click();	
		driver.findElement(fullName).sendKeys(fullname);
		
	}
	
	By Email = By.xpath("//input[@id='txtEmail']");
	public void FillEmail(String email) {
		// Filling the email
		driver.findElement(Email).click();	
		driver.findElement(Email).sendKeys(email);
		
	}
	
	By MobileNumber = By.xpath("//input[@id='mobNumber']");
	By viewPlansButton = By.xpath("//div[@class='button btnOrange' and contains(text(),'View Prices')]");
	public void FillMobileNumber(String phonenumber) {
		// Filling the mobile number and clicking the view plans button
		driver.findElement(MobileNumber).click();	
		driver.findElement(MobileNumber).sendKeys(phonenumber);	
		driver.findElement(viewPlansButton).click();
		WebElement ErrorMessage = driver.findElement(By.cssSelector("body.stopscroll"));
		capture.takescreenshot(ErrorMessage,"ErrorMessage");
		
	}
	
	By errorMsgEmail = By.xpath("//div[contains(text(),'email')]");
	By errorMsgPhoneNumber = By.xpath("//div[contains(text(),'mobile')]");
	public void ErrorMessage() throws IOException {
		// Displaying the error message for email and mobile number
		WebElement email = driver.findElement(errorMsgEmail);
		String emailText = email.getText();
		
		WebElement Pno = driver.findElement(errorMsgPhoneNumber);
		String pNoText = Pno.getText();
		
		System.out.println(emailText);
		
		System.out.println(pNoText);			
		
		extentTest.log(Status.PASS, "Error Messages");
		extentTest.log(Status.INFO, "Email Error Message: " + emailText);
		extentTest.log(Status.INFO, "Phone Number Error Message: " + pNoText);		
		
	}
	
	public void closeBrowser() {
		// Closing the browser
		driver.quit();
	}
	
}

# Find travel insurance plan for students
##### Problem Statement : Find travel insurance plan for students

1. display three lowest international  travel insurance plan with amount and insurance provider company
2. Group of  2 student people (Age 22,21)
3. For any European country
(Suggested Site: policybazaar however you are free to use any other legitimate site)\

##### Detailed Description: Hackath Ideas

1. Find travel insurance plan for students, for 2 people (Age 22 & 21) & any European country, fill further dummy details & display three lowest international  travel insurance plan with amount and insurance provider company
2. Get a Car Insurance quote, proceed without  car number, keep filling details, give invalid email or phone number & capture the error message
3.  Retrieve all Health Insurance menu items and store in a List; Display the same
(Suggested Site: policybazaar.com however you are free to use any other legitimate site)

##### Key Automation Scope

Handling alerts, search option


Validation of date controls


Filling simple form, Capture warning message


Extract menu items & store in collections


Navigating back to home page

##### Plugins and Tools:
1. Selenium Webdriver and it's concepts.
2. TestNG framework and it's concepts.
3. Core java Concepts
4. Cross Browsers Testing concepts(Chrome, Edge, Firefox).
5. Create Extent Report
6. Capture The Screenshots,
7. Data Pushed to the text files,
8. Property file concepts.
9. Page Object Model.
10. Maven project.
11. Apache POI Tools.

[RemoteTestNG] detected TestNG version 7.4.0
SLF4J: Failed to load class "org.slf4j.impl.StaticLoggerBinder".
SLF4J: Defaulting to no-operation (NOP) logger implementation
SLF4J: See http://www.slf4j.org/codes.html#StaticLoggerBinder for further details.
Starting ChromeDriver 114.0.5735.90 (386bc09e8f4f2e025eddae123f36f6263096ae49-refs/branch-heads/5735@{#1052}) on port 26050
Only local connections are allowed.
Please see https://chromedriver.chromium.org/security-considerations for suggestions on keeping ChromeDriver safe.
## ChromeDriver was started successfully.
Jul 19, 2023 1:18:57 PM org.openqa.selenium.devtools.CdpVersionFinder findNearestMatch
WARNING: Unable to find an exact match for CDP version 114, so returning the closest version found: 112
Insurance - Compare & Buy Insurance Plans – Health, Term, Life, Car
HealthInsurancelist:.......
Family Health Insurance
Senior Citizen Health Insurance
Health Insurance for Parents
Best Health Insurance Plans
Maternity Insurance
Health Insurance Portability
Mediclaim Policy
Critical Illness Insurance
Health Insurance Calculator
Health Insurance Companies
Health Insurance for NRIs
Health Insurance Claim
log4j:WARN No appenders could be found for logger (freemarker.cache).
log4j:WARN Please initialize the log4j system properly.
log4j:WARN See http://logging.apache.org/log4j/1.2/faq.html#noconfig for more info.
Starting ChromeDriver 114.0.5735.90 (386bc09e8f4f2e025eddae123f36f6263096ae49-refs/branch-heads/5735@{#1052}) on port 15106
Only local connections are allowed.
Please see https://chromedriver.chromium.org/security-considerations for suggestions on keeping ChromeDriver safe.
## ChromeDriver was started successfully.
Jul 19, 2023 1:19:05 PM org.openqa.selenium.devtools.CdpVersionFinder findNearestMatch
WARNING: Unable to find an exact match for CDP version 114, so returning the closest version found: 112
Insurance - Compare & Buy Insurance Plans – Health, Term, Life, Car
Clicked on Travel Insurance
Japan
Start Date: Jul 30, 2023
End Date: Aug 29, 2023
Error: The 'MovetoNextpage' element is not clickable within the timeout.
InsuranceCompanyProviderNames: [Reliance, Bajaj Allianz, Care Health]
InsurancePrice: [1,514, 1,628, 2,156]
Starting ChromeDriver 114.0.5735.90 (386bc09e8f4f2e025eddae123f36f6263096ae49-refs/branch-heads/5735@{#1052}) on port 3207
Only local connections are allowed.
Please see https://chromedriver.chromium.org/security-considerations for suggestions on keeping ChromeDriver safe.
## ChromeDriver was started successfully.
Jul 19, 2023 1:19:27 PM org.openqa.selenium.devtools.CdpVersionFinder findNearestMatch
WARNING: Unable to find an exact match for CDP version 114, so returning the closest version found: 112
Insurance - Compare & Buy Insurance Plans – Health, Term, Life, Car
Get Car Insurance starting at only ₹2,094/year #
Ad Popup closed.
Please enter valid email address
Please enter mobile number

===============================================
Suite
Total tests run: 25, Passes: 25, Failures: 0, Skips: 0
===============================================
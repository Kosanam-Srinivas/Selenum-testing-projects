package IRCTCautomation.miniProject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFEvaluationWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
    
    public String readexcel(int row, int cell) throws IOException {
        // Get the current directory
        String userDir = System.getProperty("user.dir");

        // Construct the file path of the Excel file
        String filePath = userDir + "\\src\\main\\java\\IRCTCautomation\\miniProject\\City.xlsx";

        // Create a File object with the file path
        File file = new File(filePath);

        // Create a FileInputStream to read the Excel file
        FileInputStream fis = new FileInputStream(file);

        // Create an XSSFWorkbook instance to represent the Excel workbook
        XSSFWorkbook wb = new XSSFWorkbook(fis);

        // Get the first sheet of the workbook
        XSSFSheet sheet = wb.getSheetAt(0);

        // Read the value from the specified row and cell in the sheet
        return String.valueOf(sheet.getRow(row).getCell(cell));
    }
}

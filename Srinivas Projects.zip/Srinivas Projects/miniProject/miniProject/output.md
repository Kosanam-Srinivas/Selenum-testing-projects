Chrome browser has been successfully opened.
Expected Title: IRCTC Next Generation eTicketing System
Actual Title: IRCTC Next Generation eTicketing System
Correct IRCTC website opened.
Ad Popup closed.
No alert present!
HYDERABAD DECAN - HYB
PUNE JN - PUNE
Selected Date: 24 JUNE/2023
Selected Class: Sleeper (SL)
Seleting the Person With Disability Concession....
Click on Find trains button....
!----------------Verify the trains displayed are correct as per the search criteria (cities)---------------------!
The Source Location is matched
The Ending Location is matched
The Date is correct
The Source Location is matched
The Ending Location is matched
The Date is correct
The Source Location is not matched
The Ending Location is matched
The Date is correct
The Source Location is not matched
The Ending Location is matched
The Date is correct
The Source Location is not matched
The Ending Location is matched
The Date is correct
The Source Location is not matched
The Ending Location is matched
The Date is correct
The Source Location is matched
The Ending Location is not matched
The Date is correct
!----------Display the number of trains available and their names on the console---------!
Number of trains available: 7
Train Names:
HUSSAIN SAGAR (12702)
MUMBAI EXP (22731)
RAJKOT SF EXP (22718)
COA LTT EXPRESS (17221)
VSKP LTT EXPRES (18519)
KONARK EXPRESS (11020)
HYB HDP EXP (17014)
Screenshot saved successfully: results__1.jpg
Browser closed successfully.
PASSED: main

===============================================
    Default test
    Tests run: 1, Failures: 0, Skips: 0
===============================================


===============================================
Default suite
Total tests run: 1, Passes: 1, Failures: 0, Skips: 0
===============================================


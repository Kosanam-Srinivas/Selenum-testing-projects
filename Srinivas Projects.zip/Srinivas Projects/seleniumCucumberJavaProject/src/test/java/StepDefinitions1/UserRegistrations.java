package StepDefinitions1;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class UserRegistrations {

	public WebDriver driver;

	@SuppressWarnings("deprecation")
	@Given("I am on the application home page")
	public void i_am_on_the_application_home_page() {
		String browserName = "chrome";
		switch (browserName) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;
		case "edge":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;
		default:
			System.out.println("Please provide a proper browser value.");
		}

		// Perform browser actions and configurations
		driver.manage().window().maximize();

		driver.get("https://www.phptravels.net/home");

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@When("I click on My Account button")
	public void click_on_my_account_button() {
		WebElement myAccountButton = driver.findElement(By.xpath("//div[@role='search']/ul/li[3]/a"));
		myAccountButton.click();
	}

	@When("I select the Sign Up link")
	public void select_the_sign_up_link() {
		WebElement signUpLink = driver.findElement(By.linkText("Signup"));
		signUpLink.click();
	}

	@When("I enter the following details:")
	public void enter_the_following_details(io.cucumber.datatable.DataTable dataTable) {
		List<Map<String, String>> details = dataTable.asMaps(String.class, String.class);

		WebElement firstNameField = driver.findElement(By.id("firstname"));
		firstNameField.sendKeys(details.get(0).get("First Name"));

		WebElement lastNameField = driver.findElement(By.name("last_name"));
		lastNameField.sendKeys(details.get(0).get("Last Name"));

		WebElement mobileNumberField = driver.findElement(By.name("phone"));
		mobileNumberField.sendKeys(details.get(0).get("Mobile Number"));

		WebElement emailField = driver.findElement(By.name("email"));
		emailField.sendKeys(details.get(0).get("Email"));

		WebElement passwordField = driver.findElement(By.name("password"));
		passwordField.sendKeys(details.get(0).get("Password"));
	}

	@Then("the details should be correctly displayed")
	public void the_details_should_be_correctly_displayed() {
		WebElement firstNameField = driver.findElement(By.id("firstname"));
		String enteredFirstName = firstNameField.getAttribute("value");
		assert enteredFirstName.equals("John") : "First Name is not correctly displayed.";

		WebElement lastNameField = driver.findElement(By.name("last_name"));
		String enteredLastName = lastNameField.getAttribute("value");
		assert enteredLastName.equals("Doe") : "Last Name is not correctly displayed.";

		WebElement mobileNumberField = driver.findElement(By.name("phone"));
		String enteredMobileNumber = mobileNumberField.getAttribute("value");
		assert enteredMobileNumber.equals("1234567890") : "Mobile Number is not correctly displayed.";

		WebElement emailField = driver.findElement(By.name("email"));
		String enteredEmail = emailField.getAttribute("value");
		assert enteredEmail.equals("john.doe@example.com") : "Email is not correctly displayed.";

		WebElement passwordField = driver.findElement(By.name("password"));
		String enteredPassword = passwordField.getAttribute("value");
		assert enteredPassword.equals("password123") : "Password is not correctly displayed.";

		driver.quit();
	}

}

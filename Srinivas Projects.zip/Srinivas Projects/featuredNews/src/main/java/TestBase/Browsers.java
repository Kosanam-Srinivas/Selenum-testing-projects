package TestBase;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Report.ExtentReportManager;
import Report.Screenshot;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Browsers {

	protected static Properties prop;

	public static WebDriver driver;


	private static final Logger logBase = LogManager.getLogger(TestBase.Browsers.class);

	public ExtentReports report = ExtentReportManager.getReportInstance();
	public ExtentTest logger;

	public Browsers() throws Exception {
		try {
			String userDir = System.getProperty("user.dir");
			prop = new Properties();
			FileInputStream ip = new FileInputStream(userDir + "\\src\\main\\java\\config\\config.properties");

			// loading properties file
			prop.load(ip);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	public static void invokeBrowser() {

		String browsername = prop.getProperty("browser");
		if (browsername.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();

		} else if (browsername.equals("firefox")) {

			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();

		} else if (browsername.equals("edge")) {

			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();

		}

		else {
			System.out.println("Please provide a proper browser value..");
		}
		driver.manage().window().maximize();
		
		driver.get(prop.getProperty("url"));

		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
		

	}

	@AfterMethod
	public void flushReports() throws Exception {
		report.flush();
	}

}

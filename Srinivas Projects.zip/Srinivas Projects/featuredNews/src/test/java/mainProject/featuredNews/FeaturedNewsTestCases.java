package mainProject.featuredNews;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import excelSheet.ListOfNewsHeadings;
import com.aventstack.extentreports.Status;

import TestBase.Browsers;

public class FeaturedNewsTestCases extends Browsers {

	public FeaturedNewsTestCases() throws Exception {
		super();
	}

	ListOfNewsHeadings HeadingList = new ListOfNewsHeadings();
	FeaturedNewsPage newsPage = new FeaturedNewsPage();

	// Invoke the browser
	@BeforeClass
	public void Driversetup() throws Exception {
		invokeBrowser();
		// driver.navigate().to("be.cognizant.com");
		System.out.println(driver.getTitle());
		
	}

	// Get user details
	@Test(priority = 1)
	public void Userdetails() throws Exception {
		newsPage.getUserDetails();
		logger = report.createTest("Featured News Test");
		try {
			logger.log(Status.PASS, "TestCase Passed");
			logger.log(Status.INFO, "User Details");
		} catch (Exception e) {
			logger.log(Status.FAIL, "TestCase Failed: " + e.getMessage());
			e.printStackTrace(); // Print the stack trace for debugging purposes
		}

	}

	// Get text of news headings
	@Test(priority = 2)
	public void Headings() throws Exception {
		newsPage.getTextOfHeadings();
		HeadingList.Headinglist();

		try {
			logger.log(Status.PASS, "TestCase Passed");
			logger.log(Status.INFO, "News Heading Details");
		} catch (Exception e) {
			logger.log(Status.FAIL, "TestCase Failed: " + e.getMessage());
			e.printStackTrace(); // Print the stack trace for debugging purposes
		}
	}

	// Get the text of news articles
	@Test(priority = 3)
	public void TextOfNews() throws Exception {
		newsPage.getNewsArticles();

		try {
			logger.log(Status.PASS, "TestCase Passed");
			logger.log(Status.INFO, "Printing News of Text");
		} catch (Exception e) {
			logger.log(Status.FAIL, "TestCase Failed: " + e.getMessage());
			e.printStackTrace(); // Print the stack trace for debugging purposes
		}
	}

	@AfterClass
	public void CloseBrowser() {
		newsPage.browser();

	}
}

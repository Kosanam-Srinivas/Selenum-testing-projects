package com.junit.helper;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class JunitTestEx1 {

	StringHelper helper = new StringHelper();
	@Test
	public void testTruncateAInFirst2Positions() {
		
		String actual = helper.truncateAInFirst2Positions("AACD");
		String expected = "CD";
		assertEquals(expected,actual);
		assertEquals("CD",helper.truncateAInFirst2Positions("ACD"));
		
	}
	
	//Test method can't have return type
	//Test method should be a public
	
	@Test
	public void test2() {
		assertEquals("CD",helper.truncateAInFirst2Positions("ACD"));
		
	}

}

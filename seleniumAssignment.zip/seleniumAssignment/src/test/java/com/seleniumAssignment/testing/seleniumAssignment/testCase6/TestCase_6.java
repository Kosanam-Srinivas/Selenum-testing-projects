package com.seleniumAssignment.testing.seleniumAssignment.testCase6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class TestCase_6 {
	
	public static void main(String[] args) throws Exception {



		System.setProperty("webdriver.edge.driver","C:\\Users\\2263246\\Desktop\\Projects\\Selenium_project\\SF\\msedgedriver.exe");

		WebDriver driver = new EdgeDriver();



		driver.get("https://www.phptravels.net/login");

		driver.manage().window().maximize();

		WebElement emailField = driver.findElement(By.name("email"));

		emailField.sendKeys("test123@example.com");

		WebElement passwordField = driver.findElement(By.cssSelector("input.form-control[type=password]"));

		passwordField.sendKeys("password1234");

		WebElement loginButton = driver.findElement(By.xpath("//button[@class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']"));

		loginButton.click();

		WebElement Account = driver.findElement(By.id("ACCOUNT"));

		Account.click();

		Thread.sleep(3000);



		// WebElement AgentLogin = driver.findElement(By.cssSelector("a.dropdown-item[href='https://phptravels.net/login']"));

		// AgentLogin.click();


		WebElement signupsupplier = driver.findElement(By.cssSelector("a.dropdown-item[href='https://phptravels.net/signup-supplier']"));

		signupsupplier.click();

		WebElement firstname = driver.findElement(By.cssSelector("input.form-control[name='first_name']"));

		firstname.click();

		firstname.sendKeys("kota");


		WebElement lastname = driver.findElement(By.cssSelector("input.form-control[name='last_name']"));

		lastname.click();

		lastname.sendKeys("Srirama");



		WebElement phone = driver.findElement(By.cssSelector("input.form-control[name='phone']"));

		phone.click();

		phone.sendKeys("9876543289");



		WebElement email = driver.findElement(By.cssSelector("input.form-control[name='email']"));

		email.click();

		email.sendKeys("Srirama231@gmail.com");



		WebElement password = driver.findElement(By.cssSelector("input.form-control[name='password']"));

		password.click();

		password.sendKeys("Sinivas");


		WebElement accountType = driver.findElement(By.className("select2-selection__arrow"));

		accountType.click();

		WebElement flightsTab = driver.findElement(By.className("active_flights waves-effect"));

		flightsTab.click();



		WebElement departureCityField = driver.findElement(By.className("active_flights waves-effect"));

		departureCityField.sendKeys("New York");


		WebElement destinationCityField = driver.findElement(By.className("form-control autocomplete-airport focus px-5"));

		destinationCityField.sendKeys("Los Angeles");

		}


}

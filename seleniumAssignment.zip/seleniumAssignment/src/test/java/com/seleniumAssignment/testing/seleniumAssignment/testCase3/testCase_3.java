/*Read inputs for google search from an excel sheet.*/

package com.seleniumAssignment.testing.seleniumAssignment.testCase3;


import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.Test;

public class testCase_3 {
	
	
	@Test
	public void dataReadTest() throws Exception {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		File src = new File("C:\\Users\\kosan\\eclipse-workspace\\seleniumAssignment\\Files\\test.xlsx");
		
		FileInputStream filesrc = new FileInputStream(src);
		
		XSSFWorkbook xsf = new XSSFWorkbook(filesrc);
		
		//.xls
		//HSSFWorkbook xsf = new HSSFWorkbook(fis);
		int i;
		for(i=0;i<3;i++) {
			driver.get("https://www.google.com/");
			driver.manage().window().maximize();
			WebElement element=driver.findElement(By.cssSelector("textarea.gLFyf[id='APjFqb']"));
			
			XSSFSheet sheet = xsf.getSheetAt(0);
			
			String dataEntry = sheet.getRow(+i).getCell(0).getStringCellValue();
			System.out.println("The data in the box is " + dataEntry);
			
			element.sendKeys(dataEntry);
			element.sendKeys(Keys.ENTER);
		}	
		driver.close();
   
			
	}
	

}

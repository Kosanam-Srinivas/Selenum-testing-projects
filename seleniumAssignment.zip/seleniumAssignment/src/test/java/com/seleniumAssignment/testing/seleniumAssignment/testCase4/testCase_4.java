/*Create multiple test cases and execute using testNG.*/

package com.seleniumAssignment.testing.seleniumAssignment.testCase4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class testCase_4 {
	
	@Test
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		System.out.println("Browser Maximized");
		System.out.println("The Google Site is Launched");
	}
	
	
	
	@Test
	public void openPhptravalswebsite() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\chromedriver.exe");
		WebDriver driver1 = new ChromeDriver();
		driver1.manage().window().maximize();
		driver1.get("https://phptravels.com/demo/");
		System.out.println("The phptravels site is launched");
	}
	
	@Test
	public void Title()
	{ 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\chromedriver.exe");
		WebDriver driver1 = new ChromeDriver();
		driver1.manage().window().maximize();
		driver1.get("https://phptravels.com/demo/");
		
		String title = driver1.getTitle(); 
		System.out.println("Prints the web page title : "+title);


	}
	
	@Test
	public void phptravelsInstantDemo() throws Exception {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\chromedriver.exe");
		WebDriver driver2 = new ChromeDriver();
		driver2.manage().window().maximize();
		driver2.get("https://phptravels.com/demo/");
		
		WebElement first_name = driver2.findElement(By.xpath("//*[@class=\"first_name input mb1\"]"));
		first_name.sendKeys("Kota");
		WebElement lastName = driver2.findElement(By.xpath("//*[@class=\"last_name input mb1\"]"));
		lastName.sendKeys("Sriram");
		WebElement Bname = driver2.findElement(By.xpath("//*[@class=\"business_name input mb1\"]"));
		Bname.sendKeys("Product Sales");
		WebElement email = driver2.findElement(By.xpath("//*[@class=\"email input mb1\"]"));
		email.sendKeys("Kotasriram123@gmail.com");
		
		WebElement result = driver2.findElement(By.xpath("//*[@id=\"number\"]"));
		result.sendKeys("15");
		Thread.sleep(10000);
		
		WebElement submit = driver2.findElement(By.xpath("//*[@id=\"demo\"]"));
		submit.click();
		
		System.out.println("We have sent your demo credentials to your email please check your email to test demo website.");
	}
	
	@Test
	public void LogIn()
	{ 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\chromedriver.exe");
		WebDriver driver1 = new ChromeDriver();
		driver1.manage().window().maximize();
		driver1.get("https://phptravels.com/demo/");
		
		driver1.findElement(By.className("//*[@id=\"loginSignup\"]/li[1]/a")).click();
		System.out.println("Login page open");

	}
	
	@Test
	public void SignUp()
	{ 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\chromedriver.exe");
		WebDriver driver1 = new ChromeDriver();
		driver1.manage().window().maximize();
		driver1.get("https://phptravels.com/demo/");
		
		WebElement element = driver1.findElement(By.className("jfHeader-menuListLink jfHeader-dynamicLink jfHeader-signup-action signup  btn-outline-dark"));
		element.click();
		System.out.println("SignUp page open");
	}
	
	
	
	

}

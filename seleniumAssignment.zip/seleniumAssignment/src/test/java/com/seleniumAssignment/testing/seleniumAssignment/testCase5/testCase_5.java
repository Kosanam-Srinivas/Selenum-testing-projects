/*Consider any website (eg. Redbus or bookmyshow) travel the entire functionality of the website using selenium..
 *  e.g., for redbus provide input for from and to locations, 
 *  select seats and navigate to payment screen.*/

package com.seleniumAssignment.testing.seleniumAssignment.testCase5;

public class testCase_5 {

}

/*Create a test automation project using selenium and maven.
 *  Using selenium open a “google.com” 
 *  website and try providing input to search.*/

package com.seleniumAssignment.testing.seleniumAssignment.testcase1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class testcase_1 {
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.com/");
		String ActualTitle=driver.getTitle();
		String ExpectedTitle="Google";
		driver.manage().window().maximize();
		
		if(ActualTitle.equals(ExpectedTitle))
		{
			System.out.println("TITLE is matched with user expectation");
		}
		
		else 
		{
			System.out.println("Title not matched");
		}
		
		WebElement element=driver.findElement(By.cssSelector("textarea.gLFyf[id='APjFqb']"));
		element.sendKeys("AI training models");
		element.sendKeys(Keys.ENTER);
		driver.get("https://www.koombea.com/blog/ai-model/");	
	}
}

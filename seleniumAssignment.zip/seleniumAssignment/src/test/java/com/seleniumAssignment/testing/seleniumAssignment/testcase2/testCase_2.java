/*Make this project to support in multiple browsers(chrome, firefox, edge) 
 * using if statements, based on input provided the automation should 
 * run on one of the browsers.*/

package com.seleniumAssignment.testing.seleniumAssignment.testcase2;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class testCase_2 {
	public static void main(String[] args) throws Exception {
        // Prompt user for browser selection
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the name of the browser to use (chrome, firefox, edge): ");
        String browserName = scanner.nextLine();

        WebDriver driver;
    
        if (browserName.equalsIgnoreCase("chrome")) 
        {
        	System.setProperty("webdriver.chrome.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\chromedriver.exe");
        	driver = new ChromeDriver();
        	System.out.println("Chrome Successfully Launched");
        	driver.get("https://www.google.com/");
        	driver.manage().window().maximize();
        	WebElement element=driver.findElement(By.cssSelector("textarea.gLFyf[id='APjFqb']"));
    		element.sendKeys("AI training models");
    		element.sendKeys(Keys.ENTER);
        } 
        else if (browserName.equalsIgnoreCase("firefox"))
        {
        	System.setProperty("webdriver.gecko.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\geckodriver.exe");
            driver = new FirefoxDriver();
            System.out.println("Firefox Successfully Launched");
            driver.get("https://www.google.com/");
            driver.manage().window().maximize();
            WebElement element=driver.findElement(By.cssSelector("textarea.gLFyf[id='APjFqb']"));
    		element.sendKeys("AI training models");
    		element.sendKeys(Keys.ENTER);
        }
        else if (browserName.equalsIgnoreCase("edge")) 
        {
        	System.setProperty("webdriver.chrome.driver","C:\\Users\\kosan\\eclipse-workspace\\Selenium_Project\\Resources\\msedgedriver.exe");
            driver = new EdgeDriver();
            System.out.println("MsEdge Successfully Launched");
            driver.get("https://www.google.com/");
            driver.manage().window().maximize();
            WebElement element=driver.findElement(By.cssSelector("textarea.gLFyf[id='APjFqb']"));
    		element.sendKeys("AI training models");
    		element.sendKeys(Keys.ENTER);
        } 
        else 
        {
            System.out.println("Invalid browser name. Please enter 'chrome', 'firefox', or 'edge'.");
            return;
        }


        Thread.sleep(3000);
        driver.close();
        scanner.close();
    }
	
}
